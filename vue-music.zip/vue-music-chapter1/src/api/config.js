export const commonParams = {  //查询参数
	g_tk:67232076,
	inCharset:'utf-8',
	outCharset:'utf-8',
	notice:0,
	format:'jsonp'
}

export const options = {  //回调
	param:'jsonpCallback'
}

export const ERR_OK = 0