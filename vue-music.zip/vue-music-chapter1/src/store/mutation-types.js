export  const SET_SINGER = "SET_SINGER"

export const SET_PLAYING = "SET_PLAYING"

export const SET_FULLSCREEN = "SET_FULLSCREEN"

export const  SET_SEQUENCELIST = "SET_SEQUENCELIST"

export const  SET_PLAYLIST = 'SET_PLAYLIST'

export const SET_CURRENTINDEX = "SET_CURRENTINDEX"

export const SET_MODE = "SET_MODE"

export const SET_DISC = "SET_DISC"

export const SET_TOP_LIST = "SET_TOP_LIST"

export const SET_PLAYHISTORY = "SET_PLAYHISTORY"

export const SET_SEARCHHISTORY = "SET_SEARCHHISTORY"

export const SET_FAVORITELIST = 'SET_FAVORITELIST'
